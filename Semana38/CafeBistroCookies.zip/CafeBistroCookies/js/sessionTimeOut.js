
let sessionTimeout; // Variável para armazenar o temporizador

function resetSessionTimeout() {
    clearTimeout(sessionTimeout); // Limpa o temporizador existente, se houver
    //  sessionTimeout = setTimeout(sessionExpired, 7 * 60 * 1000); // Define um novo temporizador para 7 minutos
    sessionTimeout = setTimeout(sessionExpired, 7 * 60 * 1000);
}
function teste() {
    // Esta função será chamada quando a sessão expirar
    // Você pode redirecionar para a página de login ou executar outras ações aqui
    alert("Mexeu o mouse!!.");
   
}

function sessionExpired() {
    // Esta função será chamada quando a sessão expirar
    // Você pode redirecionar para a página de login ou executar outras ações aqui
    alert("Sua sessão expirou. Por favor, faça login novamente!!!.");
    window.location.href = "login.php"; // Redireciona para a página de login
}
// Função para atualizar a variável de sessão no servidor
function atualizarSessao() {
    // Cria um objeto XMLHttpRequest
    let xhr = new XMLHttpRequest();

    // Configura a solicitação
    xhr.open("GET", "../controladora/atualizar_sessao.php", true);

    // Envia a solicitação
    xhr.send();
}

// Event listeners para interações do usuário que redefinem o temporizador e atualizam a sessão no servidor
document.addEventListener("mousemove", function() {
    resetSessionTimeout();
    atualizarSessao();
    teste();
}); // Move o mouse

document.addEventListener("keypress", function() {
    resetSessionTimeout();
    atualizarSessao();
}); // Pressiona tecla do teclado

document.addEventListener("click", function() {
    resetSessionTimeout();
    atualizarSessao();
}); // Clica na página

// Inicia o temporizador quando a página carrega
window.onload = resetSessionTimeout;
