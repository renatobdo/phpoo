<?php
session_start();
require_once '../controladora/controleAcesso.php';
require_once 'menu.php';


include '..\controladora\conexao.php';
include '..\Modelo\Produto.php';
include '..\Repositorio\ProdutoRepositorio.php';

$produtosRepositorio = new ProdutoRepositorio($conn);
$cafes = $produtosRepositorio->listarCafes();
$almocos = $produtosRepositorio->listarAlmocos();
?>
<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="icon" href="../img/icone-serenatto.png" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet">
    <title>IFSP - Cardápio</title>
</head>

<body>
    <main>
    <?php include '../controladora/tempoSessao.php'; ?>
        <section class="container-banner">
            <div class="container-texto-banner">
                <img src="../img/logo-ifsp-removebg.png" class="logo" alt="logo-serenatto">
            </div>
        </section>
        <h2>Cardápio Digital</h2>
        <section class="container-cafe-manha">
            <div class="container-cafe-manha-titulo">
                <h3>Opções para o Café</h3>
                <img class="ornaments" src="../img/ornaments-coffee.png" alt="ornaments">
            </div>
            <div class="container-cafe-manha-produtos">
                <?php


                foreach ($cafes as $cafe) : ?>
                    <div class="container-produto">
                        <div class="container-foto">
                            <img src="<?= $cafe->getImagemDiretorio() ?>">
                        </div>
                        <p><?= $cafe->getNome() ?></p>
                        <p><?= $cafe->getDescricao() ?></p>
                        <p><?= "R$ " . number_format($cafe->getPreco(), 2) ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
        <section class="container-almoco">
            <div class="container-almoco-titulo">
                <h3>Opções para o Almoço</h3>
                <img class="ornaments" src="../img/ornaments-coffee.png" alt="ornaments">
            </div>
            <div class="container-almoco-produtos">
                <?php


                foreach ($almocos as $almoco) : ?>
                    <div class="container-produto">
                        <div class="container-foto">
                            <img src="<?= $almoco->getImagemDiretorio() ?>">
                        </div>
                        <p><?= $almoco->getNome() ?></p>
                        <p><?= $almoco->getDescricao() ?></p>
                        <p><?= "R$ " . number_format($almoco->getPreco(), 2) ?></p>
                    </div>
                <?php endforeach; ?>
            </div>

        </section>
    </main>
</body>
<!-- Seu HTML -->
<!-- Inclua este script no final do corpo ou use eventos de carregamento de página para garantir que o DOM esteja carregado -->
<script>
    let sessionTimeout; // Variável para armazenar o temporizador

function resetSessionTimeout() {
    clearTimeout(sessionTimeout); // Limpa o temporizador existente, se houver
    //  sessionTimeout = setTimeout(sessionExpired, 7 * 60 * 1000); // Define um novo temporizador para 7 minutos
    sessionTimeout = setTimeout(sessionExpired, 5 * 1000);
}
//function teste() {
    // Esta função será chamada quando a sessão expirar
    // Você pode redirecionar para a página de login ou executar outras ações aqui
 //   alert("Mexeu o mouse!!.");
   
//}

function sessionExpired() {
    // Esta função será chamada quando a sessão expirar
    // Você pode redirecionar para a página de login ou executar outras ações aqui
    alert("Sua sessão expirou. Por favor, faça login novamente!!!.");
    window.location.href = "login.php"; // Redireciona para a página de login
}
// Função para atualizar a variável de sessão no servidor
function atualizarSessao() {
    // Cria um objeto XMLHttpRequest
    let xhr = new XMLHttpRequest();

    // Configura a solicitação
    xhr.open("GET", "../controladora/atualizar_sessao.php", true);

    // Envia a solicitação
    xhr.send();
}

// Event listeners para interações do usuário que redefinem o temporizador e atualizam a sessão no servidor
document.addEventListener("mousemove", function() {
    resetSessionTimeout();
    atualizarSessao();
   // teste();
}); // Move o mouse

document.addEventListener("keypress", function() {
    resetSessionTimeout();
    atualizarSessao();
}); // Pressiona tecla do teclado

document.addEventListener("click", function() {
    resetSessionTimeout();
    atualizarSessao();
}); // Clica na página

// Inicia o temporizador quando a página carrega
window.onload = resetSessionTimeout;

</script> 


</html>
