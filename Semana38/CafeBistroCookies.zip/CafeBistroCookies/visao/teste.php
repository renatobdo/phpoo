<?php
// Array de produtos
$produtos = [
    ['nome' => 'Camiseta', 'preco' => 19.99, 'categoria' => 'Roupas'],
    ['nome' => 'Tênis', 'preco' => 59.99, 'categoria' => 'Calçados'],
    ['nome' => 'Fones de Ouvido', 'preco' => 29.99, 'categoria' => 'Eletrônicos'],
    ['nome' => 'Livro', 'preco' => 12.50, 'categoria' => 'Livros']
];

// Exibição dos produtos usando divs e foreach
?>

<div class="produtos-container">
    <?php foreach ($produtos as $produto): ?>
        <div class="produto">
            <h2><?php echo $produto['nome']; ?></h2>
            <p><strong>Preço:</strong> R$ <?php echo 
                number_format($produto['preco'], 2, ',', '.'); ?></p>
            <p><strong>Categoria:</strong> <?php echo 
                $produto['categoria']; ?></p>
        </div>
    <?php endforeach; ?>
</div>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "QF";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
$sql = "SELECT nome, preco, categoria FROM produtos";
$result = $conn->query($sql);
?>
<div class="produtos-container">
    <?php if ($result->num_rows > 0): ?>
        <?php foreach ($result as $produto): ?>
            <div class="produto">
                <h2><?php echo $produto['nome']; ?></h2>
                <p><strong>Preço:</strong> R$ <?php echo 
                    number_format($produto['preco'], 2, ',', '.'); ?></p>
                <p><strong>Categoria:</strong> <?php echo 
                    $produto['categoria']; ?></p>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Nenhum produto encontrado.</p>
    <?php endif; ?>
</div>
<?php
$conn->close();
?>





<style>
    .produtos-container {
        display: flex;
        flex-wrap: wrap;
    }

    .produto {
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        margin: 10px;
        width: 200px;
    }

    .produto h2 {
        margin-top: 0;
    }
</style>
