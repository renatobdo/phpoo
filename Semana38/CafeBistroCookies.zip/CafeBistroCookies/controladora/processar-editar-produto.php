<?php
session_start();
require '../visao/menu.php';
require_once "conexao.php";
require '../Repositorio/ProdutoRepositorio.php';
require '../Modelo/Produto.php';
// ...

//$codigo = rand(0, 100000);
$produtosRepositorio = new ProdutoRepositorio($conn);

if (isset($_POST['editar'])){
    $produto = new Produto($_POST['id'], 
    $_POST['tipo'], $_POST['nomeP'], $_POST['descricao'], $_POST['preco']);

    //se a imagem foi carregada
    if (isset($_FILES['imagem']['name']) && ($_FILES['imagem']['error'] == 0)){
        $testeImagem = true;
        $produto->setImagem($_FILES['imagem']['name']);
        move_uploaded_file($_FILES['imagem']['tmp_name'], $produto->getImagemDiretorio());
    }elseif ($_FILES['imagem']['error'] == UPLOAD_ERR_NO_FILE){
      $produto->setImagem('');
    }

  
    $imagem = $_FILES['imagem']['name'];
    $imagemError = $_FILES['imagem']['error'];
    
    $produtosRepositorio->atualizarProduto($produto);
  //  header("Location: ../visao/admin.php?codedit=$codigo");
    
    echo "<form id='redirectForm' action='../visao/admin.php?imagemNome={$imagem}&testeError={$imagemError}' method='POST'>";
    echo "<input type='hidden' name='id' value='{$_POST['id']}'>";
    echo "<input type='hidden' name='tipo' value='{$_POST['tipo']}'>";
    echo "<input type='hidden' name='nomeP' value='{$_POST['nomeP']}'>";
    echo "<input type='hidden' name='descricao' value='{$_POST['descricao']}'>";
    echo "<input type='hidden' name='preco' value='{$_POST['preco']}'>";
    echo "</form>";
    echo "<script>document.getElementById('redirectForm').submit();</script>";



}