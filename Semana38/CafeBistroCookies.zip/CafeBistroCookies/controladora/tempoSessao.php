<!DOCTYPE html>
<html>
<head>
    <title>Cronômetro Decrescente</title>
</head>
<body>
    <div id="cronometro">Tempo restante: 2:00</div>

    <script>
        // Função para formatar o tempo em minutos e segundos
        function formatarTempo(segundos) {
            var min = Math.floor(segundos / 60);
            var sec = segundos % 60;
            return min + ':' + (sec < 10 ? '0' : '') + sec;
        }

        // Função para iniciar o cronômetro
        function iniciarCronometro() {
            var segundos = 420; // 7 minutos

            var elementoCronometro = document.getElementById('cronometro');

            // Atualiza o cronômetro a cada segundo
            var interval = setInterval(function() {
                segundos--;
                elementoCronometro.textContent = 'Tempo restante: ' + formatarTempo(segundos);

                if (segundos <= 0) {
                    clearInterval(interval); // Para o cronômetro quando chegar a 0
                    alert('Tempo esgotado!');
                }
            }, 1000); // 1000 milissegundos = 1 segundo
        }

        // Inicia o cronômetro quando a página carregar
        window.onload = iniciarCronometro;
    </script>
</body>
</html>
