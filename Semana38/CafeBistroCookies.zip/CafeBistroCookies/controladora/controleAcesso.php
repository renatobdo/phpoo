<?php

if (!isset($_SESSION["nomeusuario"])) {

  header("Location: login.php?erro=usuario não logado!");
  exit;
}
if (isset($_SESSION['nome_cookie_login'])) {
  // Verifica se o cookie "novo_cookie" existe
  $tempo_expiracao_cookie =  $_SESSION['LAST_ACTIVITY'];

  $tempoMaximoSessao = 420; // Tempo máximo da sessão em segundos (30 minutos)
  if (time() > $tempo_expiracao_cookie) {
    // O tempo atual é maior que o tempo de expiração do cookie
    echo '<script type="text/javascript">
    alert("Sua sessão expirou. Por favor, faça login novamente.");
    window.location.href = "../controladora/logout.php"; // Redireciona para login.php
  </script>';
    //} else {
    // O cookie ainda está dentro do tempo de expiração
    //    echo "O cookie está válido.";
    // }
    //} else {
    //  echo "O cookie 'cookieRenato' não foi encontrado.";
  }/* else {

    $_SESSION['LAST_ACTIVITY'] = time(); // Atualiza a última atividade na sessão

    $tempoRestante = $tempoMaximoSessao - (time() - $_SESSION['LAST_ACTIVITY']);
   
    $segundosRestantes = $tempoRestante % 60;

    echo '<p id="tempo_restante">Tempo restante: ' . $segundosRestantes . ' segundos</p>';
  }*/
}
?>

<script>
// Atualiza o contador a cada segundo
/*setInterval(function() {
    // Atualiza o tempo restante na tela
    var tempoRestante = <?php //echo $segundosRestantes; ?>;
    document.getElementById("tempo_restante").innerText = "Tempo restante: " + tempoRestante + " segundos";
    tempoRestante--; // Decrementa o tempo restante
}, 1000); // Atualiza a cada 1 segundo (1000ms)*/
</script> 

