<?php
session_start();

$_SESSION['LAST_ACTIVITY'] = time() + 10; // Atualiza a última atividade na sessão
?>
