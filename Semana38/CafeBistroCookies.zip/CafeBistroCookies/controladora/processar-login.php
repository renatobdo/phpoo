<?php
require "conexao.php";
require "Autenticacao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    $login = new autenticacao($conn);
    $usuario = $login->verificarUsuario($email, $senha);
    if ($usuario) {
        $token = bin2hex(random_bytes(16)); // Gera um token de 16 bytes (32 caracteres hexadecimais)

        // Define o cookie com o token e tempo de expiração
        $tempo_expiracao = time() + 420; // Por exemplo, 7 min de tempo de expiração
        //420 = 7 min
    
        setcookie("cookieRenato", $token, $tempo_expiracao );

        // Armazena o nome do cookie em uma variável de sessão para uso posterior
        session_start();
        $_SESSION['LAST_ACTIVITY']  = $tempo_expiracao ;
        $_SESSION['nome_cookie_login'] = "cookieRenato";

       $cookie =  $_SESSION['nome_cookie_login'];

        $_SESSION["usuario"] = true;
        $_SESSION["nomeusuario"] = $usuario["nome"];
        $_SESSION["fotousuario"] = $usuario["foto"];
        $_SESSION["menu"] = true;
        header("Location: ../visao/index.php?cookie=$cookie&tempo=$tempo_expiracao");
        exit();
    } else {

        header("Location: ../visao/login.php?erro=1");
    }
}
