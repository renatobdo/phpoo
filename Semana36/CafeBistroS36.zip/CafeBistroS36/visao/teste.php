<?php
echo "Olá";
?>